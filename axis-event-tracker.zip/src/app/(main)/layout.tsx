import { redirect } from 'next/navigation';
import { createClient, isSupabaseConfigured } from '@/lib/supabase/server';
import { db } from '@/server/db';
import { users } from '@/server/db/schema';
import { eq } from 'drizzle-orm';
import { AppShell } from '@/components/layout/app-shell';

export default async function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Check if we're in demo mode (no Supabase OR no database)
  const isDemoMode = !isSupabaseConfigured() || !process.env.DATABASE_URL;

  if (isDemoMode) {
    // Demo mode - use mock user
    return (
      <AppShell
        user={{
          name: 'Demo User',
          email: 'demo@example.com',
          role: 'event_registration_crew',
        }}
      >
        {children}
      </AppShell>
    );
  }

  const supabase = await createClient();

  if (!supabase) {
    redirect('/login');
  }

  const { data: { user: authUser } } = await supabase.auth.getUser();

  if (!authUser) {
    redirect('/login');
  }

  // Get user from our database
  const dbUser = await db?.query.users.findFirst({
    where: eq(users.email, authUser.email!),
  });

  if (!dbUser) {
    // User authenticated but not in our system - sign out
    await supabase.auth.signOut();
    redirect('/login');
  }

  return (
    <AppShell
      user={{
        name: dbUser.name,
        email: dbUser.email,
        role: dbUser.role,
      }}
    >
      {children}
    </AppShell>
  );
}
