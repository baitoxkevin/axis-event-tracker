import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    // Skip type checking during build to speed up deployment
    ignoreBuildErrors: true,
  },
};

export default nextConfig;
